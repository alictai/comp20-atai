/*
 * Assignment 5 Solution
 * by Alison Tai
 */

//Express initialization
var express = require('express');
var app = express(express.logger());
app.use(express.bodyParser());
app.set('scorecenter', 'nodeapp');

//Mongo initialization
var dburl = process.env.MONGOLAB_URI ||
			process.env.MONGOHQ_URL ||
			'mongodb://localhost/scorecenter';
var collections = ['scores'];
var db = require('mongojs').connect(dburl, collections);

//Score model object
function score (game_title, username, score) {
	this.game_title = game_title;
	this.username = username;
	this.score = score;
	this.created_at = new Date().toString();
}

//HOME - lists all scores for all games
app.get('/', function (request, response) {
	var resp = "<table border='1' >";
	resp += "<h1>High Scores</h1>"
	resp += "<tr><b><td><h3>Game</h3></td><td><h3>Username</h3></td><td><h3>Score</h3></td></b></tr>";
	db.scores.find().sort({game_title:1,  score:1}, function(err, scores) {
		if (err || !scores.length) {
			console.log("User not found");
		} else {
			scores.forEach(function(score) {
				resp += "<tr>";
				resp += "<td>" + score.game_title + "</td>";
				resp += "<td>" + score.username + "</td>";
				resp += "<td>" + score.score + "</td>";
				resp += "<tr>";
			});
		}
		resp += "</table>";
		response.set('Content-Type', 'text/html');
		response.send(resp);
	});
});

//POST API
app.post('/submit.json', function(request, response) {
	response.header('Access-Control-Allow-Origin', '*');
	response.header('Access-Control-Allow-Headers', 'X-Requested-With');

	var game = request.body.game_title;
	var un = request.body.username;
	var highscore = Number(request.body.score);
	var new_score = new score(game, un, highscore);
	db.scores.save(new_score, function(err, savedScore) {
		if (err || !savedScore) 
			console.log("Score of user " + score.username + " not saved because " + err);
		else
			response.set('Content-Type', 'text/json');
			response.send(new_score);
	});
});

//GET API
app.get('/highscores.json', function(request, response) {
	response.header('Access-Control-Allow-Origin', '*');
	response.header('Access-Control-Allow-Headers', 'X-Requested-With');
	
	var game = request.query.game_title;
	var top_10 = [];
	db.scores.find({game_title:game}).sort({score:-1}).limit(10, function(err, scores) {
		if (err || !scores.length) {
			console.log("Game not found");
		} else {
			scores.forEach(function(score) {
				top_10.push(score);
			});
		}
		response.set('Content-Type', 'text/json');
		response.send(top_10);
	});
});

// USERNAME SEARCH
app.get('/usersearch', function(request, response) {
	response.send("<form id='input' name='search' action='user_find' method='post'>Username: <input type='text' name='username'><input type='submit' id='submit' value='Submit'></form>");
	var username = request.body.username;
});

app.post('/user_find', function(request, response) {
	var un = request.body.username;
	var resp = "<table border='1' >";
	resp += "<h1>" + un + " High Scores</h1>"
	resp += "<tr><b><td><h3>Game</h3></td><td><h3>Username</h3></td><td><h3>Score</h3></td></b></tr>";
	db.scores.find({username:un}).sort({username:1,  game:1, score:-1}, function(err, scores) {
		if (err || !scores.length) {
			resp += "<h2>User not found.</h2>";
		} else {
			scores.forEach(function(score) {
				resp += "<tr>";
				resp += "<td>" + score.game_title + "</td>";
				resp += "<td>" + score.username + "</td>";
				resp += "<td>" + score.score + "</td>";
				resp += "<tr>";
			});
		}
		resp += "</table>";
		response.set('Content-Type', 'text/html');
		response.send(resp);
	});
});

app.listen(process.env.PORT || 3000);
